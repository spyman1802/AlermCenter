package com.huacai.Model;

import lombok.Data;

@Data
public class WXRes {
  int code;
  String media;
  String reply;
}
